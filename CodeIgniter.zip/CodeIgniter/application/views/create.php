<html ng-app="myModule">
    <head>
        <title>Insert</title>
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="<?php echo base_url('/assets/js/jquery.validate.min.js'); ?>"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
        <script src="<?php echo base_url('/assets/js/script.js'); ?>"></script>
        <script src="<?php echo base_url('/assets/js/angular.min.js'); ?>"></script>

        <style>
          #contactform label.error{color:red;font-size:13px}
        </style>
       
    </head>

    <body >
    <nav class="nav bg-dark">
            <h3 style="color:white">Insert new Contacts</h3>
    </nav>
    <a href="<?php echo base_url().'index.php/user/index';?>" class="btn btn-warning mt-4 mb-4" style="margin-left:45%">Home</a>

    <div class="container mt-4 mb-4" ng-controller='userCtrl'>

    <form name="createUser" ng-submit="submitForm()">
            <div class="form-group">
                <label for="name">Name</label>
                <input type="text" class="form-control" id="name" ng-model="user.name" name="name" placeholder="Enter Name">
                <span id="name_error" class="text-danger"></span>
            </div>
            <div class="form-group">
                <label for="phone">Phone No.</label>
                <input type="number" class="form-control" id="phone" ng-model="user.phone" name="phone" placeholder="Enter Phone Number">
                <span id="phone_error" class="text-danger"></span>
            </div>
            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" class="form-control" id="email" ng-model="user.email" name="email" placeholder="Enter email">
                <span id="email_error" class="text-danger"></span>
            </div>
            <div class="form-group">
                <label for="dob">Date of Birth</label>
                <input type="date" class="form-control" id="dob" ng-model="user.dob" name="dob" required placeholder="date of birth">
                <span id="dob_error" class="text-danger"></span>
            </div>
            <div  class="radio">
                <label for="gender">Gender</label><br>
                Male<input type="radio" ng-model="user.gender" name="gender" id="gender" value="male"><br>
                Female<input type="radio" ng-model="user.gender"name="gender"  id="gender" value="female" >
                <span id="gender_error" class="text-danger"></span>
            </div>
            <button  type="submit" value="Submit" class="btn btn-primary mt-3">Submit</button>
        </form>
    </div>

    </body>

</html>
