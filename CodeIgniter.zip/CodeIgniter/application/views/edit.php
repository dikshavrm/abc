<html>
    <head>
        <title>Update Contact</title>
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="<?php echo base_url('/assets/js/jquery.validate.min.js'); ?>"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
        <script src="<?php echo base_url('/assets/js/script.js'); ?>"></script>

        <script src="<?php echo base_url('/assets/js/angular.min.js'); ?>"></script>


        <script>
            var did = "<?php echo $user['id']; ?>";
        </script>
        <script src="<?php echo base_url('/assets/js/script.js'); ?>"></script>

        <style>
          #contactformedit label.error{
              color:red;font-size:13px
              }
        </style>

    </head>

    <body ng-app="myModules" ng-controller='userCtrls'>

    <nav class="nav bg-dark">
            <h3 style="color:white">Update Contact</h3>
    </nav>
    <a href="<?php echo base_url().'index.php/user/index';?>" class="btn btn-warning mt-4 mb-4" style="margin-left:45%">Home</a>

    <div class="container mt-4 mb-4">
        <form name="updateUser" id="contactformedit" onsubmit="editFunction()">
        <input type="hidden" class="form-control" id="id" name="id" placeholder="Enter Name" value="<?php echo set_value('name',$user['name']); ?>">

            <div class="form-group">
                <label for="name">Name</label>
                <input type="text" class="form-control" id="name" name="name" placeholder="Enter Name" value="<?php echo set_value('name',$user['name']); ?>">
                <span id="name_error" class="text-danger"></span>
            </div>
            <div class="form-group">
                <label for="phone">Phone No.</label>
                <input type="number" class="form-control" id="phone" name="phone" placeholder="Enter Phone Number" value="<?php echo set_value('phone',$user['phone']); ?>">
                <span id="phone_error" class="text-danger"></span>
            </div>
            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" class="form-control" id="email" name="email" placeholder="Enter email" value="<?php echo set_value('email',$user['email']); ?>">
                <span id="email_error" class="text-danger"></span>
            </div>
            <div class="form-group">
                <label for="dob">Date of Birth</label>
                <input type="date" class="form-control" id="dob" name="dob" required placeholder="date of birth" value="<?php echo set_value('dob',$user['dob']); ?>">
                <span id="dob_error" class="text-danger"></span>
            </div>
            <div  class="radio">
                <label for="gender">Gender</label><br>
                <input type="radio" name="gender" id="gender" <?php echo ($user['gender']=='male')?'checked':'' ?> value="male">Male<br>
                <input type="radio" name="gender" id="gender" <?php echo ($user['gender']=='female')?'checked':'' ?> value="female">Female
                <span id="gender_error" class="text-danger"></span>
            </div>
            <button  type="submit" value="Submit" class="btn btn-primary mt-3">Submit</button>
        </form>
</div>
    </body>

</html>
