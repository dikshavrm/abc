<html ng-app="myModule">
    <head>
        <title>Users</title>
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="<?php echo base_url('/assets/js/jquery.validate.min.js'); ?>"></script>
        <script src="<?php echo base_url('/assets/js/script.js'); ?>"></script>
        <script src="<?php echo base_url('/assets/js/angular.min.js'); ?>"></script>
        <script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.6.9/angular-route.js"></script>
    </head>

    <body ng-app='myapp'>

        <nav class="nav bg-dark">
            <h3 style="color:white">View Contacts</h3>
        </nav>

        <a href="<?php echo base_url().'index.php/user/create';?>" class="btn btn-info mt-4 mb-4" style="margin-left:45%">Insert new contact</a>

        <div ng-controller='userCtrl'>
        <table class="table table-striped">
            <tr class="bg-warning">
                <th>Name</th>
                <th>Phone</th>
                <th>Email</th>
                <th>Date of Birth</th>
                <th>Gender</th>
                <th>Edit</th>
                <th>Delete</th>
            </tr>

            <tbody>
                <tr ng-repeat='user in users'>
                    <td>{{ user.name }}</td>
                    <td>{{ user.phone }}</td>
                    <td>{{ user.gender }}</td>
                    <td>{{ user.email }}</td>
                    <td>{{ user.dob }}</td>
                    <!-- <td><button class="btn btn-success" ng-click="edit(user.id)">Edit</td> -->
                    <td><a href="edits/{{user.id}}"><button class="btn btn-success">Edit</button></a></td>
                    <td><button class="btn btn-danger" ng-click="delete(user.id)">Delete</button></td>

                </tr>
            </tbody>
        </table>
        </div>

    </body>

</html>
