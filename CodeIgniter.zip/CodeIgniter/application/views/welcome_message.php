<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Welcome to CodeIgniter</title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">

	<style type="text/css">


	#container {
		margin: 10px;
		border: 1px solid #D0D0D0;
		box-shadow: 0 0 8px #D0D0D0;
		background-color:cyan;
	}
	</style>
</head>
<body>

<div id="container">
	<h3 style="text-align:center">Contact Book List</h3> 
</div>

<a href="<?php echo base_url().'index.php/user/index';?>" class="btn btn-info mt-4 mb-4" style="margin-left:45%">View Contact List</a>


</body>
</html>