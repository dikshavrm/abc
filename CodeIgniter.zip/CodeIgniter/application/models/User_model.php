<?php
// defined('BASEPATH') OR exit('No direct script access allowed');

 class User_model extends CI_model{
   
    
     function create($formArray)
     {
         $this->db->insert('contacts',$formArray);
        //  if ($this->db->affected_rows() > 0)
        //     {
        //     return TRUE;
        //     }
        //     else
        //     {
        //     return FALSE;
        //     }
           
     }

     function all(){
         return $users = $this->db->get('contacts')->result_array();
     }

     function getUser($id){
         $this->db->where('id',$id);
         return $user = $this->db->get('contacts')->row_array();
     }

     function updateUser($id,$formArray){
        $this->db->where('id',$id);
        $this->db->update('contacts',$formArray);
        if($this->db->affected_rows() == true)
        {
            return true;
        }
        else
        {        
            return true;
        }

    }

     function deleteUser($id){
        $this->db->where('id',$id);
        $this->db->delete('contacts');
        // if($this->db->affected_rows() == true)
        // {
        //     return true;
        // }
        // else
        // {        
        //     return true;
        // }
    }
 }
?>