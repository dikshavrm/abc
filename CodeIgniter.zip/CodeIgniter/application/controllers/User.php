<?php

class User extends CI_Controller {
   
        function index(){
            $this->load->view('list');
        }

        function get_contacts(){
            $this->load->model('User_model');
            $users=$this->User_model->all();
            $response = array(
                'Success'=>true,
                'Data'=>$users,
                'Message'=>"Data show Successfully"
               );
            echo json_encode($response);
        }


        function create(){
            $this->load->view('create');
        }

        function saveData()
        {
               
               $this->load->model('User_model');
               $request= json_decode(file_get_contents('php://input'), TRUE);
            //    $data = json_decode($request);
               $this->load->library('form_validation');
               $this->form_validation->set_rules('name','Name','trim|required|min_length[5]|max_length[20]');
               $this->form_validation->set_rules('email','Email','trim|required|valid_email');
               $this->form_validation->set_rules('phone','Phone','trim|required|min_length[10]|max_length[10]');
               $this->form_validation->set_rules('dob','DOB','required');
               $this->form_validation->set_rules('gender','Gender','required');
               $array=array();
               if($this->form_validation->run()==false){
                    $array = array(
                    'error'   => true,
                    'name_error' => form_error('name'),
                    'email_error' => form_error('email'),
                    'phone_error' => form_error('phone'),
                    'dob_error' => form_error('dob'),
                    'gender_error' => form_error('gender'),
                    
                   );
                   $response=array(
                    'Success'=>false,
                    'Data'=>$array,
                    'Message'=>"Validation Failed"
                );
               }
               
               else{
                
                    $formArray = array();
                    $formArray['name']=$this->input->post('name');
                    $formArray['phone']=$this->input->post('phone');
                    $formArray['email']=$this->input->post('email');
                    $formArray['dob']=$this->input->post('dob');
                    $formArray['gender']=$this->input->post('gender');
                    $this->User_model->create($formArray);
                    $response = array(
                        'Success'=>true,
                        'Data'=>$formArray,
                        'Message'=>"Data Inserted Successfully"
                    );
                    //    $check=$this->User_model->create($formArray);
                    //    if($check==true){echo 'Data Inserted Successfully';}
                    //    else{echo 'Data Insertion failed';} 
               }
            echo json_encode($response);
            }


            function editData($id){
                $this->load->model('User_model');
                $user = $this->User_model->getUser($id);
                $data=array();
                $data['user']=$user;
            }

            function edits($id){

                $this->load->model('User_model');
                $user = $this->User_model->getUser($id);
                $data=array();
                $data['user']=$user;
                $this->load->view('edit',$data);

                // $response = array(
                //     'Success'=>true,
                //     'Data'=> $data,
                //     'Message'=>"Data show Successfully"
                //    );
                // echo json_encode($response);

               
                // $response = array(
                //     'Success'=>true,
                //     'Data'=>$user,
                //     'Message'=>"Data show Successfully"
                //    );
                // echo json_encode($response);
            }

            function edit($id){
               
                $this->load->model('User_model');
                $user = $this->User_model->getUser($id);
                // $data=array();
                // $data['user']=$user;
                $this->load->library('form_validation');
                $this->form_validation->set_rules('name','Name','trim|required|min_length[5]|max_length[20]');
                $this->form_validation->set_rules('email','Email','trim|required|valid_email');
                $this->form_validation->set_rules('phone','Phone','trim|required|min_length[10]|max_length[10]');
                $this->form_validation->set_rules('dob','DOB','required');
                $this->form_validation->set_rules('gender','Gender','required');

                // $this->form_validation->set_rules('name','Name','required');
                // $this->form_validation->set_rules('email','Email','required');
                // $this->form_validation->set_rules('phone','Phone','required');
                // $this->form_validation->set_rules('dob','DOB','required');
                // $this->form_validation->set_rules('gender','Gender','required');
                $array=array();

                if($this->form_validation->run()==false){
                    $array = array(
                        'error'   => true,
                        'name_error' => form_error('name'),
                        'email_error' => form_error('email'),
                        'phone_error' => form_error('phone'),
                        'dob_error' => form_error('dob'),
                        'gender_error' => form_error('gender'),
                       );
                    $response=array(
                        'Success'=>false,
                        'Data'=>$array,
                        'Message'=>"Updation Failed"
                    );
                }
                else{

                $formArray = array();
                $formArray['id']=$this->input->post('id');

                $formArray['name']=$this->input->post('name');
                $formArray['phone']=$this->input->post('phone');
                $formArray['email']=$this->input->post('email');
                $formArray['dob']=$this->input->post('dob');
                $formArray['gender']=$this->input->post('gender');
                $this->User_model->updateUser($id,$formArray);
                $response=array(
                    'Success'=>true,
                    'Data'=>$formArray,
                    'Message'=>"Updation Successful"
                );
                // $check=$this->User_model->updateUser($id,$formArray);
                // if($check==true){echo 'Data Updated Successfully';}
                // else{echo 'Data Updation failed';}
                // $this->session->set_flashdata('success','Records updated');
                // redirect(base_url().'index.php/user/index');
                }
                echo json_encode($response);

            }
     
            function delete($id){
                $this->load->model('User_model');
                $user = $this->User_model->getUser($id);
                if (empty($user)){
                    redirect(base_url().'index.php/user/index');
                }
                $this->User_model->deleteUser($id);
                $check=$this->User_model->deleteUser($id);
                // if($check==true){echo 'Data Deleted Successfully';}
                // else{echo 'Data Deletion failed';}
                $response = array(
                    'Success'=>true,
                    'Data'=>$user,
                    'Message'=>"Data deleted"
                   );
                echo json_encode($response);
                redirect(base_url().'index.php/user/index');
                }
    }

?>