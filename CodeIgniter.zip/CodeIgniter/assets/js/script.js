var baseurl='http://localhost:8000/index.php/user';

    function editData(){
        console.log(id);
        console.log('Success');
        var fetch = angular.module('myModules', []);
        fetch.controller('userCtrls', ['$scope', '$http', function ($scope, $http) {
                    console.log('Success');
                    $scope.getData = function(){
                        console.log('Success');
                        $http({
                            method: 'GET',
                            url: baseurl+'/edits/'+id
                        }).then(function successCallback(response) {
                            console.log(response);
                           })
                       }
                       $scope.getData();
        }])
    }

// List Page

    function getContacts(){
        var fetch = angular.module('myModule', []);

        // fetch.config(function ($routeProvider) {
        //     $routeProvider
        //         .when("/edit", {
        //             templateUrl: "edit.php",
        //             controller: "userCtrl"
        //         })
        // })

        fetch.controller('userCtrl', ['$scope', '$http', function ($scope, $http) {
            $scope.user = {};
            $scope.submitForm=function()
            {                       
             console.log('passed');
             console.log($scope.user);
                   $http({
                    method:'post',
                    url:baseurl+'/saveData',
                    data : $scope.user, //forms user object
                    headers : {'Content-Type': 'application/x-www-form-urlencoded'} 
                }).then(function successCallback(data)
                {
                        $scope.message=data;
                        console.log($scope.message.data);
                        console.log('passed');
                });
            };

            $scope.getUsers = function(){
                $http({
                 method: 'GET',
                 url: baseurl+'/get_contacts'
                }).then(function successCallback(response) {
                  // Assign response to users object
                  console.log(response);
                  console.log(response.data);

                  console.log(response.data.Data);
                  
                  $scope.users =response.data.Data;
                }); 
               }
               $scope.getUsers();


               $scope.edit = function(id){
                console.log('jkdj');
                $http({
                    method: 'GET',
                    url: baseurl+'/edits/'+id
                   }).then(function successCallback(users) {
                       console.log(users);
                       console.log(users.data);
                       $scope.user =users.data.Data;

                    //    console.log(users.data.Data);
                       
                    //    $scope.users =users.data.Data;
                     // Assign response to users object
                    //  $scope.users =response.data.Data;
                    //  console.log( $scope.users);
                    //  console.log('jkdj');

                      }); 

                }

                $scope.delete  = function(id) {
                  $http({
                        method : 'DELETE',
                        url : baseurl+'/delete/'+id
                    })
                    window.location.href = "index";      
                }
             }]);
        }

        // $.ajax({
        //     url:baseurl+'/get_contacts',
        //     type:'GET',
        //     success: function(response) {
        //         response=JSON.parse(response);
        //         console.log(response);
        //         buildTable(response.Data);
        //     }
        // });
        
  

    $(document).ready(function(){
        getContacts();
        myFunction();
        editFunction();
        editData();

    });

    // function buildTable(data){
    //     var table = document.getElementById('myTable')

    //     for (var i = 0; i < data.length; i++){
    //         var row = `<tr>
    //                         <td>${data[i].name}</td>
    //                         <td>${data[i].phone}</td>
    //                         <td>${data[i].email}</td>
    //                         <td>${data[i].dob}</td>
    //                         <td>${data[i].gender}</td>
    //                         <td onclick="document.location = 'edits/${data[i].id}'"><button class="btn btn-success">Edit</button></td>
    //                         <td onclick="document.location = 'delete/${data[i].id}'"><button class="btn btn-danger">Delete</button></td>
    //                 </tr>`
    //         table.innerHTML += row
    //     }
    // }



// Create Page
function myFunction() {
    $(document).ready(function(){
        $("#contactform").validate({
         rules: {
    
             name: {
                 required: true,
                 minlength:3,
             },
             phone: {
                 required: true,
                 minlength:10,
                 maxlength:10,
             },
             email: {
                 required: true,
                 email: true
                 
             },
             gender: {
                 required: true,
                 
             },
         },
    
         messages:{
             name:
                 {
                     required:"Name is required",
                     minlength:"Length should be greater than 3"
                 },
                 phone:
                 {
                     required:"Phone Number is required",
                     minlength:"Length should be 10",
                     maxlength:"Length should be 10"
    
                 },
                 email:
                 {
                     email:"Email format is incorrect",
                     required:"Email is required",
                 },
                 gender:
                 {
                     required:"Gender is required",
                 },
                  dob:"Date of Birth is required",
    
         },
         submitHandler:function(form){
            
             $.ajax({
                 url: baseurl+'/saveData',
                 type: "POST",
                 data: $('#contactform').serialize(),
                 dataType: "json",
    
                 success: function(data) {
                    console.log(data);
                    console.log(data.Data);
                    console.log(data.Data.name_error);
                    
                    if(data.Data.error)
                        {
                        if(data.Data.name_error != '')
                        {
                        $('#name_error').html(data.Data.name_error);
                        }
                        else
                        {
                        $('#name_error').html('');
                        }
   
                        if(data.phone_error != '')
                        {
                        $('#phone_error').html(data.phone_error);
                        }
                        else
                        {
                        $('#phone_error').html('');
                        }
   
                        if(data.email_error != '')
                        {
                        $('#email_error').html(data.email_error);
                        }
                        else
                        {
                        $('#email_error').html('');
                        }
   
                        if(data.gender_error != '')
                        {
                        $('#gender_error').html(data.gender_error);
                        }
                        else
                        {
                        $('#gender_error').html('');
                        }
   
                        if(data.dob_error != '')
                        {
                        $('#dob_error').html(data.dob_error);
                        }
                        else
                        {
                        $('#dob_error').html('');
                        }
   
                        }
                        else{
                            window.location = 'http://localhost:8000/index.php/User/index';
                        }
                },
             });
         }
        });
    });
      }


// edit
var did;
var id= did;
console.log(id);

function editFunction() {
   
    $(document).ready(function(){
        $("#contactformedit").validate({
        rules: {

            name: {
                required: true,
                minlength:3,
            },
            phone: {
                required: true,
                minlength:10,
                maxlength:10,
            },
            email: {
                required: true,
                email: true
                
            },
            gender: {
                required: true,
                
            },
        },

        messages:{
            name:
                {
                    required:"Name is required",
                    minlength:"Length should be greater than 3"
                },
                phone:
                {
                    required:"Phone Number is required",
                    minlength:"Length should be 10",
                    maxlength:"Length should be 10"

                },
                phone:
                {
                    email:"Email format is incorrect",
                    required:"Email is required",
                },
                gender:
                {
                    required:"Gender is required",
                },
                dob:"Date of Birth is required",

        },

        submitHandler:function(form){
            $.ajax({
                url:baseurl+'/edit/'+id,
                type: "POST",
                data: $('#contactformedit').serialize(),
                dataType: "json",

                success: function(data) {
                    console.log(data);
                    console.log(data.Data);
                    console.log(data.Data.name_error);

                    if(data.Data.error)
                        {
                        if(data.Data.name_error != '')
                        {
                        $('#name_error').html(data.Data.name_error);
                        }
                        else
                        {
                        $('#name_error').html('');
                        }
   
                        if(data.phone_error != '')
                        {
                        $('#phone_error').html(data.phone_error);
                        }
                        else
                        {
                        $('#phone_error').html('');
                        }
   
                        if(data.email_error != '')
                        {
                        $('#email_error').html(data.email_error);
                        }
                        else
                        {
                        $('#email_error').html('');
                        }
   
                        if(data.gender_error != '')
                        {
                        $('#gender_error').html(data.gender_error);
                        }
                        else
                        {
                        $('#gender_error').html('');
                        }
   
                        if(data.dob_error != '')
                        {
                        $('#dob_error').html(data.dob_error);
                        }
                        else
                        {
                        $('#dob_error').html('');
                        }
   
                        }
                        else{
                            window.location = 'http://localhost:8000/index.php/User/index';
                        }
                },
            
            });
        }
        // submitHandler:function(){
        //     form.submit();
        // }
        });
    });
}
