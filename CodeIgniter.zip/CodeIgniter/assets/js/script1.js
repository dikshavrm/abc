function editData(){
  console.log('Success');

  var fetch = angular.module('myModule', []);
  fetch.controller('userCtrl', ['$scope', '$http', function ($scope, $http) {
      $scope.getUsers = function(){
          $http({
           method: 'GET',
           url: baseurl+'/get_contacts'
          }).then(function successCallback(response) {
            // Assign response to users object
            console.log(response);
            console.log(response.data);

            console.log(response.data.Data);
            
            $scope.users =response.data.Data;
          }); 
         }
         $scope.getUsers();

         
       }]);
  }
